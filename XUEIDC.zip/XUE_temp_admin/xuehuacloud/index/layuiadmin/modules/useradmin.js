/**

 @Name：layuiAdmin 用户管理 管理员管理 角色管理
 @Author：star1029
 @Site：http://www.layui.com/admin/
 @License：LPPL
    
 */ 


layui.define(['table', 'form'], function(exports){
  var $ = layui.$
  ,table = layui.table
  ,form = layui.form;
    //plugin列表
    table.render({
    elem: '#LAY-user-plugin_addon'
    ,url: '../admin.php?c=plugin_addon&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
     
      ,{field: 'plugin_name', width: 180, title: '名称'}
      ,{field: 'plugin_type', width: 150, title: '类型'}
	  
	   ,{field: 'money', width: 120, title: '价格'}
	   ,{field: 'plugin_state', width: 180, title: '状态'}
	  
     
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-0'
    ,text: '对不起，加载出现异常！'
  });
    //myplugin列表
    table.render({
    elem: '#LAY-user-myplugin'
    ,url: '../admin.php?c=myplugin&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      
      ,{field: 'plugin_name', width: 180, title: '名称'}
      ,{field: 'plugin_type', width: 150, title: '类型'}
	  
	   ,{field: 'plugin_state', width: 180, title: '状态'}
     
    ]]
    ,page: true
    ,limit: 13
    ,height: 'full-50'
    ,text: '对不起，加载出现异常！'
  });  
  //--------------------------
  
  
   //--------------------------
  table.render({
    elem: '#LAY-user-ggwenzhang'
    ,url: '../admin.php?c=ggwenzhang&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'g_name', width: 320, title: '文章标题'}
      ,{field: 'tid', width: 100, title: '排序'}//templet: '#imgTpl'
      ,{field: 'state', width: 130, title: '状态'}

      
      ,{field: 'g_date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-ggwenzhang'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-ggwenzhang)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellidcapi&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-ggwenzhang');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-ggwenzhang');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
      var idsa = data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑文章'
        ,content: 'g.html?id='+data.id
        ,maxmin: true
        ,area: ['85%', '85%']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-ggwenzhang-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
var layeditCt = layer.getChildFrame('#LAY_layedit_1',index).contents().find('body');	

      var content = layeditCt[0].innerHTML;
	  content = content.replace(/&/g, 'FGGGGQQ');
	  content = content.replace(/\+/g, 'AAARRRRFFF');
	  content = content.replace(/\r\n/g, 'HUANHANG');
	  content = content.replace(/\n/g, 'HUANHANG');
	  content = content.replace(/\s/g, 'KONGGEFU');
      content = content.replace(/\#/g, 'AGKHHJS');
      content = content.replace(/\$/g, 'adfgfdrr');
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=ggwenzhang',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
           oAjax.send("act=addsgg"+"&g_name="+field.g_name+"&g_content="+content+"&tid="+field.tid+"&id="+idsa);
			oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-ggwenzhang');
						  table.reload('LAY-ggwenzhang-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });   
  //-------------------------- 
  
  
  
 
   //--------------------------
  table.render({
    elem: '#LAY-user-odswenzhang'
    ,url: '../admin.php?c=odswenzhang&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'title', width: 320, title: '工单名称'}
     
      ,{field: 'state', width: 130, title: '状态'}
      ,{field: 'cpid', width: 180, title: '关联产品'}

      
      
      ,{field: 'endtime', width: 190,title: '最后回复', sort: true}
	  ,{field: 'addtime', width: 190,title: '提交时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-odswenzhang'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-odswenzhang)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellidcapi&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-odswenzhang');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-odswenzhang');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
      var idsa = data.id;
	  
      layer.open({
        type: 2
        ,title: '查看工单'
        ,content: 'ods.html?id='+data.id
        ,maxmin: true
        ,area: ['90%', '90%']
        ,btn: ['跟进回复', '关闭']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-odswenzhang-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
var layeditCt = layer.getChildFrame('#LAY_layedit_1',index).contents().find('body');	

      var content = layeditCt[0].innerHTML;
	  content = content.replace(/&/g, 'FGGGGQQ');
	  content = content.replace(/\+/g, 'AAARRRRFFF');
	  content = content.replace(/\r\n/g, 'HUANHANG');
	  content = content.replace(/\n/g, 'HUANHANG');
	  content = content.replace(/\s/g, 'KONGGEFU');
      content = content.replace(/\#/g, 'AGKHHJS');
      content = content.replace(/\$/g, 'adfgfdrr');
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=odswenzhang',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
           oAjax.send("act=addsgg"+"&g_content="+content+"&id="+idsa);
			oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-odswenzhang');
						  //table.reload('LAY-odswenzhang-front-submit'); //数据刷新
						  //layer.close(index); //关闭弹层
						  window['layui-layer-iframe' + index].location.reload();
                          layer.msg('回复成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('回复失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });   
  //-------------------------- 
  
  
  
  
  
  
  
  
  
  table.render({
    elem: '#LAY-user-idcapi'
    ,url: '../admin.php?c=idcahref&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'api_name', width: 150, title: '接口名称'}
      ,{field: 'api_url', width: 220, title: 'API URL'}//templet: '#imgTpl'

      ,{field: 'api_uid', width: 120, title: 'API ID'}
      ,{field: 'api_user', width: 120, title: 'API USER'}
      ,{field: 'api_cpid', width: 180, title: 'API TYPE'}
      
      
      ,{field: 'date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-idcapi'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-idcapi)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellidcapi&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-idcapi');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-idcapi');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑API'
        ,content: 'idcform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-idcapi-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editidcapi&ids="+ids+"&api_name="+field.api_name+"&api_url="+field.api_url+"&api_uid="+field.api_uid+"&api_user="+field.api_user+"&api_key="+field.api_key+"&api_admin="+field.api_admin+"&api_cpid="+field.api_cpid);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-idcapi');
						  table.reload('LAY-idcapi-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });   
  //--------------------------
  table.render({
    elem: '#LAY-user-urlahref'
    ,url: '../admin.php?c=urlahref&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'webname', width: 120, title: '网站名称'}
      ,{field: 'url', width: 220, title: 'URL'}//templet: '#imgTpl'

      ,{field: 'state', width: 120, title: '状态'}
      ,{field: 'target', width: 120, title: '打开方式'}
      
      
      ,{field: 'date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-urlahref'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-urlahref)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellurl&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-urlahref');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-urlahref');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑友联'
        ,content: 'urlform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-urlahref-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editurl&ids="+ids+"&webname="+field.webname+"&url="+field.url+"&state="+field.state+"&target="+field.target);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-urlahref');
						  table.reload('LAY-urlahref-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  }); 
  //产品分类
   table.render({
    elem: '#LAY-user-classname'
    ,url: '../admin.php?c=classname&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'class_name', width: 150, title: '分类名称'}
      ,{field: 'class_type', width: 150, title: '类型'}//templet: '#imgTpl'
      ,{field: 'class_first', width: 150, title: '实名'}//templet: '#imgTpl'

     
      
      ,{field: 'date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-classname'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-classname)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除该么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellclass&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-classname');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-classname');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑分类'
        ,content: 'classform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-classname-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editclass&ids="+ids+"&class_name="+field.class_name+"&class_type="+field.class_type+"&class_tid="+field.class_tid+"&class_first="+field.class_first);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-classname');
						  table.reload('LAY-classname-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  }); 
  

  //host列表
    table.render({
    elem: '#LAY-user-hostadmin'
    ,url: '../admin.php?c=hostadmin&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'uid', width: 70, title: 'UID'}
      ,{field: 'siteid', width: 70, title: '站点'}
      ,{field: 'host_name', width: 150, title: '名称'}
      ,{field: 'host_user', width: 120, title: '账号'}
      ,{field: 'host_pass', width: 120, title: '密码'}
      ,{field: 'state', width: 80, title: '状态'}
      ,{field: 'host_domain', width: 100, title: '域名'}
      ,{field: 'host_domains', width: 150, title: '赠送域名'}
      ,{field: 'host_size', width: 100, title: '空间容量'}
      ,{field: 'host_sqltype', width: 100, title: 'SQL类型'}
      ,{field: 'host_mysql', width: 100, title: 'SQL容量'}
      ,{field: 'host_site', width: 100, title: '子目录'}
      ,{field: 'host_network', width: 100, title: '宽带'}
      ,{field: 'host_jscripts', width: 150, title: '语言'}
      ,{field: 'host_htaccess', width: 120, title: '伪静态'}
      ,{field: 'orderid', width: 220, title: '订单号'}
      ,{field: 'addtime', width: 190,title: '购买时间', sort: true}
      ,{field: 'endtime', width: 190,title: '到期时间', sort: true}
      ,{title: '操作', width: 220, align:'center', fixed: 'right', toolbar: '#table-useradmin-hostadmin'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-hostadmin)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=vpsadmin&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-hostadmin');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-hostadmin');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '获取最新密码'
        ,content: '../index.php?m=user&c=host_pass&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['获取新密码', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-hostadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edithostpass&cpid="+field.cpid);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-hostadmin');
						  table.reload('LAY-user-hostadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('获取成功 密码已更新');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('获取失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-hostadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'xf'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '续费产品'
        ,content: '../index.php?m=user&c=host_xf&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定续费', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-hostadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=xfhost&cpid="+field.cpid+"&buytime="+field.buytime);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-hostadmin');
						  table.reload('LAY-user-hostadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('续费成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('续费失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-hostadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'gl'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '产品管理'
        ,content: '../index.php?m=user&c=host_ad&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['进入控制面板', '关闭']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-hostadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
		//layer.load();	
 //layer.close(index);actions
 window.open("../index.php?m=api&c=api&actions=loginhost&cpid="+field.cpid);   
  
 exit();
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=loginhost&cpid="+field.cpid+"&adminurl="+field.adminurl);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-hostadmin');
						  table.reload('LAY-user-hostadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('续费成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('续费失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-vpsadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  



  //cdn列表
    table.render({
    elem: '#LAY-user-cdnadmin'
    ,url: '../admin.php?c=cdnadmin&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'uid', width: 70, title: 'UID'}
      ,{field: 'siteid', width: 70, title: '站点'}
      ,{field: 'cdn_name', width: 150, title: '名称'}
      ,{field: 'cdn_user', width: 120, title: '账号'}
      ,{field: 'cdn_pass', width: 120, title: '密码'}
      ,{field: 'state', width: 80, title: '状态'}
      ,{field: 'cdn_domain', width: 100, title: '域名'}
      ,{field: 'cdn_ddos', width: 120, title: '防御'}
      ,{field: 'cdn_cc', width: 130, title: 'CC'}
      ,{field: 'cdn_flow', width: 100, title: '流量'}
      ,{field: 'orderid', width: 220, title: '订单号'}
      ,{field: 'addtime', width: 190,title: '购买时间', sort: true}
      ,{field: 'endtime', width: 190,title: '到期时间', sort: true}
      ,{title: '操作', width: 220, align:'center', fixed: 'right', toolbar: '#table-useradmin-cdnadmin'}
  
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-cdnadmin)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=vpsadmin&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-cdnadmin');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-cdnadmin');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '获取最新密码'
        ,content: '../index.php?m=user&c=cdn_pass&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['获取新密码', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-cdnadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editcdnpass&cpid="+field.cpid);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-cdnadmin');
						  table.reload('LAY-user-cdnadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('获取成功 密码已更新');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('获取失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-cdnadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'xf'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '续费产品'
        ,content: '../index.php?m=user&c=cdn_xf&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定续费', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-cdnadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=xfcdn&cpid="+field.cpid+"&buytime="+field.buytime);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-cdnadmin');
						  table.reload('LAY-user-cdnadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('续费成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('续费失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-cdnadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'gl'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '产品管理'
        ,content: '../index.php?m=user&c=cdn_ad&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['进入控制面板', '关闭']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-cdnadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
		//layer.load();	
 //layer.close(index);actions
 window.open("../index.php?m=api&c=api&actions=logincdn&cpid="+field.cpid);   
  
 exit();
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=logincdn&cpid="+field.cpid+"&adminurl="+field.adminurl);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-cdnadmin');
						  table.reload('LAY-user-cdnadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('续费成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('续费失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-vpsadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  


  //aff列表
    table.render({
    elem: '#LAY-user-user_aff'
    ,url: '/XUE/index.html?c=user_aff&m=index&aff_act=get_api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}

      ,{field: 'uid', width: 120, title: '推广人ID'}
      ,{field: 'agent_uid', width: 120, title: '注册人ID'}
      ,{field: 'user_name', width: 180, title: '注册人帐号'}
      ,{field: 'regtime', width: 180, title: '注册时间'}
      ,{field: 'reg_money', width: 120, title: '邀请奖励'}
     
      
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-user_aff)', function(obj){
    var data = obj.data;

  });  


  //VPS列表
    table.render({
    elem: '#LAY-user-vpsadmin'
    ,url: '../admin.php?c=vpsadmin&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}

      ,{field: 'uid', width: 70, title: 'UID'}
      ,{field: 'siteid', width: 70, title: '站点'}
      ,{field: 'vps_name', width: 150, title: '名称'}
      ,{field: 'vps_user', width: 120, title: '账号'}
      ,{field: 'vps_pass', width: 120, title: '密码'}
      ,{field: 'state', width: 80, title: '状态'}
      ,{field: 'vps_cpu', width: 100, title: 'CPU'}
      ,{field: 'vps_memory', width: 100, title: '内存'}
      ,{field: 'vps_ip', width: 80, title: 'IP'}
      ,{field: 'vps_disk', width: 90, title: '硬盘'}
      ,{field: 'vps_vm', width: 90, title: '虚拟化'}
      ,{field: 'vps_network', width: 80, title: '宽带'}
      ,{field: 'orderid', width: 220, title: '订单号'}
      ,{field: 'addtime', width: 190,title: '购买时间', sort: true}
      ,{field: 'endtime', width: 190,title: '到期时间', sort: true}
      ,{title: '操作', width: 220, align:'center', fixed: 'right', toolbar: '#table-useradmin-vpsadmin'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-vpsadmin)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=vpsadmin&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-vpsadmin');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-vpsadmin');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '获取最新密码'
        ,content: '../index.php?m=user&c=vps_pass&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['获取新密码', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-vpsadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editvpspass&cpid="+field.cpid);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-vpsadmin');
						  table.reload('LAY-user-vpsadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('获取成功 密码已更新');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('获取失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-vpsadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'xf'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '续费产品'
        ,content: '../index.php?m=user&c=vps_xf&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定续费', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-vpsadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=xfvps&cpid="+field.cpid+"&buytime="+field.buytime);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-vpsadmin');
						  table.reload('LAY-user-vpsadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('续费成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('续费失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-vpsadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'gl'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '产品管理'
        ,content: '../index.php?m=user&c=vps_ad&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['进入控制面板', '关闭']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-vpsadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
		//layer.load();	
 //layer.close(index);actions
 window.open("../index.php?m=api&c=api&actions=loginvps&cpid="+field.cpid);   
  
 exit();
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=loginvps&cpid="+field.cpid+"&adminurl="+field.adminurl);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-vpsadmin');
						  table.reload('LAY-user-vpsadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('续费成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('续费失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-vpsadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  

  //卡密列表
    table.render({
    elem: '#LAY-user-paycard'
    ,url: '../admin.php?c=paycard&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'uid', width: 100, title: '使用者'}
      ,{field: 'money', width: 100, title: '金额'}
      ,{field: 'state', width: 120, title: '状态'}
      ,{field: 'paycard', width: 180, title: '卡密'}
      ,{field: 'endtime', width: 190, title: '使用时间'}


    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-paycard)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=paycard&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-paycard');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-vpsadmin');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){

    } else if(obj.event === 'xf'){

    } else if(obj.event === 'gl'){

    }
  });  
  
  //coupon
    table.render({
    elem: '#LAY-user-coupon'
    ,url: '../admin.php?c=coupon&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
	   ,{field: 'coupon', width: 130, title: '优惠卷'}
      ,{field: 'znum', width: 100, title: '可用次数'}
      ,{field: 'uidnum', width: 100, title: '用户次数'}
      ,{field: 'money', width: 100, title: '折扣金额'}
      ,{field: 'used', width: 100, title: '已用次数'}
      ,{field: 'uid', width: 110, title: '绑定用户'}
      ,{field: 'cpid', width: 110, title: '绑定产品'}
     
      ,{field: 'endtime', width: 190, title: '生成时间'}


    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-coupon)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=coupon&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-coupon');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-coupon');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){

    } else if(obj.event === 'xf'){

    } else if(obj.event === 'gl'){

    }
  });  

  //rent列表
    table.render({
    elem: '#LAY-user-rentadmin'
    ,url: '../admin.php?c=rentadmin&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
	 ,{title: '操作', width: 160, align:'center', toolbar: '#table-useradmin-rentadmin'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}

      ,{field: 'vps_users', width: 120, title: 'UID=用户'}
      ,{field: 'vps_name', width: 150, title: '名称'}
      ,{field: 'vps_user', width: 120, title: '账号'}
      ,{field: 'vps_pass', width: 120, title: '密码'}
      ,{field: 'state', width: 80, title: '状态'}
      ,{field: 'vps_cpu', width: 150, title: 'CPU'}
      ,{field: 'vps_memory', width: 100, title: '内存'}
      ,{field: 'vps_ip', width: 80, title: 'IP'}
      ,{field: 'vps_disk', width: 150, title: '硬盘'}
      ,{field: 'vps_ddos', width: 90, title: '硬防'}
      ,{field: 'vps_network', width: 80, title: '宽带'}
      ,{field: 'orderid', width: 220, title: '订单号'}
      ,{field: 'addtime', width: 190,title: '购买时间', sort: true}
      ,{field: 'endtime', width: 190,title: '到期时间', sort: true}
      
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-rentadmin)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=rentadmindell&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-rentadmin');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-rentadmin');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '获取最新密码'
        ,content: 'index.php?m=user&c=vps_pass&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['获取新密码', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-rentadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editvpspass&cpid="+field.cpid);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-rentadmin');
						  table.reload('LAY-user-rentadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('获取成功 密码已更新');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('获取失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-rentadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'xf'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '续费产品'
        ,content: '../index.php?m=user&c=rent_xf&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定续费', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-rentadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','index.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=xfrent&cpid="+field.cpid+"&buytime="+field.buytime);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-rentadmin');
						  table.reload('LAY-user-rentadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('续费成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('续费失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-rentadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'gl'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '产品管理'
        ,content: '../index.php?m=user&c=rent_ad&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确认', '关闭']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-rentadmin-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
		//layer.load();	
 //layer.close(index);actions
 //layer.close(index);exit();
 //window.open("index.php?m=api&c=api&actions=loginvps&cpid="+field.cpid);   
  
//exit();
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=uprents&cpid="+field.cpid+"&user="+field.user+"&pass="+field.pass+"&ip="+field.ip+"&state="+field.state);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-rentadmin');
						  table.reload('LAY-user-rentadmin-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('保存成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('保存失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-rentadmin-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  







  
  //服务器租用列表
  table.render({
    elem: '#LAY-user-rent'
    ,url: '../admin.php?c=rent&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'rent_name', width: 150, title: '名称'}
      ,{field: 'class_id', width: 120, title: '分类'}//templet: '#imgTpl'
	   ,{field: 'state', width: 120, title: '状态'}
      ,{field: 'rent_system', width: 130, title: '系统'}
      ,{field: 'rent_cpu', width: 80, title: 'CPU'}
      ,{field: 'rent_memory', width: 120,title: '内存'}
      ,{field: 'rent_ip', width: 80,title: 'IP'}
      ,{field: 'rent_disk', width: 80,title: '硬盘'}
      ,{field: 'rent_network', width: 80,title: '宽带'}
      ,{field: 'rent_ddos', width: 80,title: '硬防'}
      ,{field: 'rent_day_money', width: 100,title: '日付'}
      ,{field: 'rent_month_money', width: 100,title: '月付'}
      ,{field: 'rent_year_money', width: 100,title: '年付'}
      ,{field: 'tid', width: 80,title: '排序'}
	  ,{field: 'num', width: 120,title: '限购次数'}
      ,{field: 'rent_date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-rent'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-rent)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellrent&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-rent');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-rent');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 'rentform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-rent-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editrent&ids="+ids+"&class_id="+field.class_id+"&api_id="+field.api_id+"&rent_name="+field.rent_name+"&rent_cpu="+field.rent_cpu+"&rent_memory="+field.rent_memory+"&rent_ip="+field.rent_ip+"&rent_disk="+field.rent_disk+"&rent_network="+field.rent_network+"&rent_ddos="+field.rent_ddos+"&rent_day_money="+field.rent_day_money+"&rent_month_money="+field.rent_month_money+"&rent_year_money="+field.rent_year_money+"&rent_system="+field.rent_system+"&tid="+field.tid+"&num="+field.num);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-rent');
						  table.reload('LAY-rent-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  }); 
  
  
  //VPS列表
  table.render({
    elem: '#LAY-user-vps'
    ,url: '../admin.php?c=vps&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'vps_name', width: 150, title: '名称'}
      ,{field: 'class_id', width: 120, title: '分类'}//templet: '#imgTpl'

      ,{field: 'api_id', width: 130, title: '接口'}
      ,{field: 'vps_api_id', width: 80, title: '编号'}
      ,{field: 'state', width: 120, title: '状态'}
      
      ,{field: 'vps_cpu', width: 80, title: 'CPU'}
      ,{field: 'vps_memory', width: 120,title: '内存'}
      ,{field: 'vps_ip', width: 80,title: 'IP'}
      ,{field: 'vps_disk', width: 80,title: '硬盘'}
      ,{field: 'vps_vm', width: 130,title: '虚拟化'}
      ,{field: 'vps_network', width: 80,title: '宽带'}
      ,{field: 'vps_day_money', width: 100,title: '日付'}
      ,{field: 'vps_month_money', width: 100,title: '月付'}
      ,{field: 'vps_year_money', width: 100,title: '年付'}
	  
      ,{field: 'tid', width: 80,title: '排序'}
	  ,{field: 'num', width: 120,title: '限购次数'}
      
      ,{field: 'vps_date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-vps'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-vps)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellvps&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-vps');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-vps');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 'vpsform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-vps-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editvps&ids="+ids+"&class_id="+field.class_id+"&api_id="+field.api_id+"&vps_api_id="+field.vps_api_id+"&vps_name="+field.vps_name+"&vps_cpu="+field.vps_cpu+"&vps_memory="+field.vps_memory+"&vps_ip="+field.vps_ip+"&vps_disk="+field.vps_disk+"&vps_vm="+field.vps_vm+"&vps_network="+field.vps_network+"&vps_day_money="+field.vps_day_money+"&vps_month_money="+field.vps_month_money+"&vps_year_money="+field.vps_year_money+"&tid="+field.tid+"&num="+field.num+"&vps_system="+field.vps_system+"&vps_bak="+field.vps_bak+"&texts="+field.texts);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-vps');
						  table.reload('LAY-vps-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  }); 
   //fikker列表
  table.render({
    elem: '#LAY-user-fikker'
    ,url: '../admin.php?c=fikker&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}

      ,{field: 'class_id', width: 180, title: '所属分类'}//templet: '#imgTpl'

      ,{field: 'api_id', width: 180, title: '绑定节点'}
      ,{field: 'date', width: 190,title: '添加时间', sort: true}
      //,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-host'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
     //s12l列表
  table.render({
    elem: '#LAY-user-s12l'
    ,url: '../admin.php?c=s12s&m=api&acta=l'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'content', width: 150, title: '折扣卷'}

      ,{field: 'zk_type', width: 120,title: '折扣类型'}// 1=首购  2=续费
      ,{field: 'zk', width: 120,title: '折扣'}
      ,{field: 'uid', width: 120,title: '绑定UID'}
      ,{field: 'cpid', width: 120,title: '使用产品'}
    

    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-s12l)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dells12l&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12l');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-s12l');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 's12form.html?acta=c&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-s12s-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edit_s12l&ids="+ids+"&zk_type="+field.zk_type+"&content="+field.content+"&num="+field.num+"&zk="+field.zk);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12l');
						  table.reload('LAY-s12l-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  
        
   
  
    //s12c列表
  table.render({
    elem: '#LAY-user-s12c'
    ,url: '../admin.php?c=s12s&m=api&acta=c'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'content', width: 150, title: '折扣卷'}

      ,{field: 'zk_type', width: 120,title: '折扣类型'}// 1=首购  2=续费
      ,{field: 'zk', width: 120,title: '折扣'}
      ,{field: 'num', width: 120,title: '可用次数'}
      ,{field: 'lnum', width: 120,title: '领取次数'}
      ,{field: 'nums', width: 120,title: '已用次数'}


      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-s12c'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-s12c)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dells12c&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12c');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-s12c');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 's12form.html?acta=c&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-s12s-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edit_s12c&ids="+ids+"&zk_type="+field.zk_type+"&content="+field.content+"&num="+field.num+"&zk="+field.zk);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12c');
						  table.reload('LAY-s12c-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  
        
  
  
  
   //s12p列表
  table.render({
    elem: '#LAY-user-s12p'
    ,url: '../admin.php?c=s12s&m=api&acta=p'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      

      ,{field: 'a_money', width: 140,title: '充值大于等于'}
      ,{field: 'e_money', width: 140,title: '充值小于不等于'}
      ,{field: 'money', width: 120,title: '赠送余额'}


      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-s12p'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-s12p)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dells12p&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12p');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-s12p');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 's12form.html?acta=p&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-s12s-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edit_s12p&ids="+ids+"&a_money="+field.a_money+"&e_money="+field.e_money+"&money="+field.money);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12p');
						  table.reload('LAY-s12p-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  
         
  
   //s12z列表
  table.render({
    elem: '#LAY-user-s12z'
    ,url: '../admin.php?c=s12s&m=api&acta=zk'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'name', width: 150, title: '名称'}

      ,{field: 'zk', width: 120,title: '折扣'}
      ,{field: 'money', width: 120,title: '原价/月'}
      ,{field: 'z_money', width: 120,title: '折扣价'}
     

      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-s12z'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-s12z)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dells12z&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12z');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-s12z');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 's12form.html?acta=zk&id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-s12s-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edit_s12z&ids="+ids+"&cpid="+field.cpid+"&zk="+field.zk);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12z');
						  table.reload('LAY-s12z-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  
         
  
  
   //s12s列表
  table.render({
    elem: '#LAY-user-s12s'
    ,url: '../admin.php?c=s12s&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'name', width: 150, title: '名称'}

      ,{field: 'kc', width: 120,title: '库存'}
      ,{field: 'month', width: 120,title: '月价'}
      ,{field: 'month6', width: 120,title: '半年'}
      ,{field: 'year', width: 120,title: '一年'}
      ,{field: 'num', width: 120,title: '限购'}

      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-s12s'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-s12s)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dells12s&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12s');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-s12s');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 's12form.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-s12s-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edit_s12s&ids="+ids+"&cpid="+field.cpid+"&kc="+field.kc+"&month="+field.month+"&month6="+field.month6+"&year="+field.year+"&num="+field.num);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-s12s');
						  table.reload('LAY-s12s-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  
       
    
  //host列表
  table.render({
    elem: '#LAY-user-host'
    ,url: '../admin.php?c=host&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'host_name', width: 150, title: '名称'}
      ,{field: 'class_id', width: 120, title: '分类'}//templet: '#imgTpl'

      ,{field: 'api_id', width: 130, title: '接口'}
      ,{field: 'host_api_id', width: 80, title: '编号'}
	   ,{field: 'state', width: 120, title: '状态'}
      ,{field: 'port', width: 100, title: '端口'}
      
      ,{field: 'host_size', width: 100, title: '容量'}
      ,{field: 'host_sqltype', width: 120,title: '数据库类型'}
      ,{field: 'host_mysql', width: 120,title: '数据库容量'}
      ,{field: 'host_site', width: 100,title: '子站点'}
      ,{field: 'host_domain', width: 150,title: '绑定域名'}
      ,{field: 'host_domains', width: 150,title: '赠送二级'}
      ,{field: 'host_network', width: 80,title: '宽带'}
      ,{field: 'host_jscripts', width: 190,title: '脚本语言'}
      ,{field: 'host_htaccess', width: 80,title: '伪静态'}
      ,{field: 'host_day_money', width: 100,title: '日付'}
      ,{field: 'host_month_money', width: 100,title: '月付'}
      ,{field: 'host_year_money', width: 100,title: '年付'}
	  
      ,{field: 'tid', width: 80,title: '排序'}
      ,{field: 'num', width: 120,title: '限购次数'}
      
      ,{field: 'host_date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-host'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-host)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellhost&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-host');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-host');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 'hostform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-host-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edithost&ids="+ids+"&class_id="+field.class_id+"&api_id="+field.api_id+"&host_api_id="+field.host_api_id+"&host_name="+field.host_name+"&host_domains="+field.host_domains+"&host_domain="+field.host_domain+"&host_size="+field.host_size+"&host_sqltype="+field.host_sqltype+"&host_mysql="+field.host_mysql+"&host_site="+field.host_site+"&host_network="+field.host_network+"&host_htaccess="+field.host_htaccess+"&host_jscripts="+field.host_jscripts+"&host_day_money="+field.host_day_money+"&host_month_money="+field.host_month_money+"&host_year_money="+field.host_year_money+"&tid="+field.tid+"&num="+field.num+"&port="+field.port+"&flow="+field.flow+"&texts="+field.texts);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-host');
						  table.reload('LAY-host-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  
     
  //cdn列表
  table.render({
    elem: '#LAY-user-cdn'
    ,url: '../admin.php?c=cdn&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'cdn_name', width: 150, title: '名称'}
      ,{field: 'class_id', width: 120, title: '分类'}//templet: '#imgTpl'

      ,{field: 'api_id', width: 130, title: '接口'}
      ,{field: 'cdn_api_id', width: 80, title: '编号'}
	   ,{field: 'state', width: 120, title: '状态'}
      ,{field: 'port', width: 100, title: '端口'}
      
      ,{field: 'cdn_domain', width: 100, title: '域名数'}
      ,{field: 'cdn_ddos', width: 120,title: 'ddos'}
      ,{field: 'cdn_cc', width: 120,title: '防CC'}
      ,{field: 'cdn_flow', width: 100,title: '流量'}

      ,{field: 'cdn_day_money', width: 100,title: '日付'}
      ,{field: 'cdn_month_money', width: 100,title: '月付'}
      ,{field: 'cdn_year_money', width: 100,title: '年付'}
	  
      ,{field: 'tid', width: 80,title: '排序'}
      ,{field: 'num', width: 120,title: '限购次数'}
      
      ,{field: 'cdn_date', width: 190,title: '添加时间', sort: true}
      ,{title: '操作', width: 150, align:'center', fixed: 'right', toolbar: '#table-useradmin-cdn'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   table.on('tool(LAY-user-cdn)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=dellcdn&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-cdn');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-cdn');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑产品'
        ,content: 'cdnform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-cdn-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=editcdn&ids="+ids+"&class_id="+field.class_id+"&api_id="+field.api_id+"&cdn_api_id="+field.cdn_api_id+"&cdn_name="+field.cdn_name+"&cdn_domain="+field.cdn_domain+"&cdn_ddos="+field.cdn_ddos+"&cdn_cc="+field.cdn_cc+"&cdn_flow="+field.cdn_flow+"&cdn_day_money="+field.cdn_day_money+"&cdn_month_money="+field.cdn_month_money+"&cdn_year_money="+field.cdn_year_money+"&tid="+field.tid+"&num="+field.num+"&port="+field.port+"&texts="+field.texts);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-cdn');
						  table.reload('LAY-cdn-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    }
  });  
  
  
  //用户列表
    table.render({
    elem: '#LAY-user-manage'
    ,url: '../admin.php?c=user_list&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'user', width: 120, title: '帐号'}
      ,{field: 'qq', width: 120, title: 'QQ'}//templet: '#imgTpl'

      ,{field: 'email', width: 180, title: '邮箱'}
      ,{field: 'state', width: 60, title: '状态'}
      ,{field: 'ren', width: 80, title: '实名'}
      
      ,{field: 'money', width: 110, title: '余额'}
      ,{field: 'z_money', width: 80,title: '总消费'}
      
      ,{field: 'date', width: 190,title: '注册时间', sort: true}
      ,{title: '操作', width: 220, align:'center', fixed: 'right', toolbar: '#table-useradmin-webuser'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user-manage)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=delluser&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-manage');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user-manage');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑用户'
        ,content: 'userform.html?id='+data.id
        ,maxmin: true
        ,area: ['95%', '95%']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edituser&ids="+ids+"&email="+field.email+"&qq="+field.qq+"&tel="+field.tel+"&pass="+field.pass+"&money="+field.money+"&state="+field.state+"&ren="+field.ren+"&vip_host="+field.vip_host+"&vip_vps="+field.vip_vps+"&vip_cdn="+field.vip_cdn);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user-manage');
						  table.reload('LAY-user-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'login'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ""+data.id;
	  window.open("../?loginuid="+ids);

    }
  });
   
  //工单客服列表
    table.render({
    elem: '#LAY-ods-manage'
    ,url: '../admin.php?c=odswenzhang&m=api&sid=up'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'user', width: 150, title: '客服帐号'}
      ,{field: 'username', width: 180, title: '客服昵称'}//templet: '#imgTpl'

      ,{field: 'kf_type', width: 180, title: '类型'}

     // ,{title: '操作', width: 220, align:'center', fixed: 'right', toolbar: '#table-useradmin-ods'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-ods-manage)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=delluser&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-ods-manage');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-ods-manage');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑用户'
        ,content: 'userform.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-ods-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edituser&ids="+ids+"&email="+field.email+"&qq="+field.qq+"&tel="+field.tel+"&pass="+field.pass+"&money="+field.money+"&state="+field.state+"&ren="+field.ren+"&vip_host="+field.vip_host+"&vip_vps="+field.vip_vps+"&vip_cdn="+field.vip_cdn);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-ods-manage');
						  table.reload('LAY-ods-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-ods-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'login'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ""+data.id;
	  window.open("../?loginuid="+ids);

    }
  });
  
 
  //下级用户列表
    table.render({
    elem: '#LAY-user_agent-manage'
    ,url: '../admin.php?c=user_agent&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'siteid', width: 80, title: '站点ID'}
      ,{field: 'user', width: 120, title: '帐号'}
      ,{field: 'qq', width: 120, title: 'QQ'}//templet: '#imgTpl'

      ,{field: 'email', width: 180, title: '邮箱'}
      ,{field: 'state', width: 60, title: '状态'}
      ,{field: 'ren', width: 80, title: '实名'}
      
      ,{field: 'money', width: 80, title: '余额'}
      ,{field: 'z_money', width: 80,title: '总消费'}
      
      ,{field: 'date', width: 190,title: '注册时间', sort: true}
      ,{title: '操作', width: 220, align:'center', fixed: 'right', toolbar: '#table-useradmin-webuser'}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //监听工具条
  table.on('tool(LAY-user_agent-manage)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
     /* layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
		*/
		var ids = ","+data.id;
        layer.confirm('真的要删除么', function(index){
          //obj.del();
		  
		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=delluser_agent&ids="+ids);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user_agent-manage');
                          layer.msg('已删除');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('删除失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  
		  
		  table.reload('LAY-user_agent-manage');
          layer.close(index);
        });
     // });
    } else if(obj.event === 'edit'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ","+data.id;
	  
      layer.open({
        type: 2
        ,title: '编辑用户'
        ,content: 'userform_agent.html?id='+data.id
        ,maxmin: true
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user_agent-front-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段

		  layer.load();
            if(window.XMLHttpRequest){
                 //非IE6
                 var oAjax=new XMLHttpRequest();
            }else{
                 var oAjax=new ActiveXObject("Microsoft.XMLHTP");

            }
            oAjax.open('POST','../admin.php?m=api&c=api',true);
			oAjax.setRequestHeader('Content-type','application/x-www-form-urlencoded');
            oAjax.send("act=edituser_agent&ids="+ids+"&email="+field.email+"&qq="+field.qq+"&tel="+field.tel+"&pass="+field.pass+"&money="+field.money+"&state="+field.state+"&ren="+field.ren);
            oAjax.onreadystatechange=function ()
            {
				  if(oAjax.readyState==4)
				  {
				      if(oAjax.status==200)
					  {
						  if(oAjax.responseText=="True"){
						  layer.closeAll('loading');
						  
						  //window.location.reload();
						  table.reload('LAY-user_agent-manage');
						  table.reload('LAY-user_agent-front-submit'); //数据刷新
						  layer.close(index); //关闭弹层
                          layer.msg('修改成功');
						  }else{
						  setTimeout(function(){ 
						  layer.closeAll('loading');
						  layer.alert('修改失败：'+oAjax.responseText, {icon: 5});
						  }, 1);
						  }
					  }else{
					       alert(oAjax.status);
					  }
				  }else{
				  //alert(oAjax.status);
				  }
            };		  
		  
		  
		  
		  
		  
		  			
			
			
			
			
			
			
			
			
			
            //table.reload('LAY-user_agent-front-submit'); //数据刷新
            
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
          
        }
      });
    } else if(obj.event === 'login'){
      var tr = $(obj.tr);
      var data = obj.data;
      var ids = ""+data.id;
	  window.open("../?loginuid="+ids);

    }
  });  
  
     //消费记录列表
    table.render({
    elem: '#LAY-user-buylog'
    ,url: '../admin.php?c=buylog&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'text_type', width: 220, title: '说明'}
      ,{field: 'buy_type', width: 100, title: '类型'}
      ,{field: 'buy_cp', width: 100, title: '产品'}
      ,{field: 'buy_money', width: 100, title: '金额'}
      ,{field: 'buy_cpid', width: 100, title: '产品ID'}
      ,{field: 'buy_cp_user', width: 120, title: '账号'}
      ,{field: 'siteid', width: 80, title: '站点'}
      ,{field: 'uid', width: 80, title: 'UID'}	  
      ,{field: 'orderid', width: 220, title: '订单号'}
      ,{field: 'date', width: 190,title: '时间', sort: true}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
     //消费记录列表
    table.render({
    elem: '#LAY-user-buylog_agent'
    ,url: '../admin.php?c=buylog_agent&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'text_type', width: 220, title: '说明'}
      ,{field: 'buy_type', width: 100, title: '类型'}
      ,{field: 'buy_cp', width: 100, title: '产品'}
      ,{field: 'buy_money', width: 100, title: '金额'}
      ,{field: 'buy_cpid', width: 100, title: '产品ID'}
      ,{field: 'buy_cp_user', width: 120, title: '账号'}
      ,{field: 'siteid', width: 80, title: '站点'}
      ,{field: 'uid', width: 80, title: 'UID'}	  
      ,{field: 'orderid', width: 220, title: '订单号'}
      ,{field: 'date', width: 190,title: '时间', sort: true}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  
   //充值记录列表
    table.render({
    elem: '#LAY-user-paylog'
    ,url: '../admin.php?c=paylog&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'uid', width: 120, title: '用户UID'}
      ,{field: 'text_type', width: 150, title: '说明'}
      ,{field: 'paytype', width: 120, title: '类型'}
      ,{field: 'money', width: 120, title: '金额'}
      ,{field: 'orders', width: 220, title: '订单号'}
      ,{field: 'state', width: 120, title: '状态'}
    
      
      ,{field: 'endtime', width: 190,title: '付款时间', sort: true}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
   //下级登录记录列表
      table.render({
    elem: '#LAY-user-loginlog_agent'
    ,url: '../admin.php?c=loginlog_agent&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'siteid', width: 70, title: '站点ID', sort: true}
      ,{field: 'uid', width: 120, title: '用户UID'}
      ,{field: 'text_type', width: 150, title: '说明'}
      ,{field: 'paytype', width: 120, title: '类型'}
      ,{field: 'money', width: 120, title: '金额'}
      ,{field: 'orders', width: 220, title: '订单号'}
      ,{field: 'state', width: 120, title: '状态'}
    
      
      ,{field: 'endtime', width: 190,title: '付款时间', sort: true}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
     //下级充值记录列表
    table.render({
    elem: '#LAY-user-paylogagent'
    ,url: '../admin.php?c=paylog_agent&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'siteid', width: 70, title: '站点ID', sort: true}
      ,{field: 'uid', width: 120, title: '用户UID'}
      ,{field: 'text_type', width: 150, title: '说明'}
      ,{field: 'paytype', width: 120, title: '类型'}
      ,{field: 'money', width: 120, title: '金额'}
      ,{field: 'orders', width: 220, title: '订单号'}
      ,{field: 'state', width: 120, title: '状态'}
    
      
      ,{field: 'endtime', width: 190,title: '付款时间', sort: true}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //登录日志列表
    table.render({
    elem: '#LAY-user-loginlog'
    ,url: '../admin.php?c=loginlog&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'uid', width: 70, title: 'UID'}
      ,{field: 'user', width: 120, title: '帐号'}
      ,{field: 'pass', width: 120, title: '密码'}
      ,{field: 'ip', width: 220, title: 'IP'}
      ,{field: 'state', width: 120, title: '状态'}
    
      
      ,{field: 'date', width: 190,title: '登录时间', sort: true}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //登录日志列表
    table.render({
    elem: '#LAY-user-loginlogs'
    ,url: '../admin.php?c=loginlogs&m=api'
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 70, title: 'ID', sort: true}
      ,{field: 'uid', width: 70, title: 'UID'}
      ,{field: 'user', width: 120, title: '帐号'}
      ,{field: 'pass', width: 120, title: '密码'}
      ,{field: 'ip', width: 220, title: 'IP'}
      ,{field: 'state', width: 120, title: '状态'}
    
      
      ,{field: 'date', width: 190,title: '登录时间', sort: true}
    ]]
    ,page: true
    ,limit: 10
    ,height: 'full-220'
    ,text: '对不起，加载出现异常！'
  });
  //管理员管理
  table.render({
    elem: '#LAY-user-back-manage'
    ,url: layui.setter.base + 'json/useradmin/mangadmin.js' //模拟接口
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 80, title: 'ID', sort: true}
      ,{field: 'loginname', title: '登录名'}
      ,{field: 'telphone', title: '手机'}
      ,{field: 'email', title: '邮箱'}
      ,{field: 'role', title: '角色'}
      ,{field: 'jointime', title: '加入时间', sort: true}
      ,{field: 'check', title:'审核状态', templet: '#buttonTpl', minWidth: 80, align: 'center'}
      ,{title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#table-useradmin-admin'}
    ]]
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-user-back-manage)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.prompt({
        formType: 1
        ,title: '敏感操作，请验证口令'
      }, function(value, index){
        layer.close(index);
        layer.confirm('确定删除此管理员？', function(index){
          console.log(obj)
          obj.del();
          layer.close(index);
        });
      });
    }else if(obj.event === 'edit'){
      var tr = $(obj.tr);

      layer.open({
        type: 2
        ,title: '编辑管理员'
        ,content: '../../../views/user/administrators/adminform.html'
        ,area: ['420px', '420px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submitID = 'LAY-user-back-submit'
          ,submit = layero.find('iframe').contents().find('#'+ submitID);

          //监听提交
          iframeWindow.layui.form.on('submit('+ submitID +')', function(data){
            var field = data.field; //获取提交的字段
            
            //提交 Ajax 成功后，静态更新表格中的数据
            //$.ajax({});
            table.reload('LAY-user-front-submit'); //数据刷新
            layer.close(index); //关闭弹层
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){           
          
        }
      })
    }
  });

  //角色管理
  table.render({
    elem: '#LAY-user-back-role'
    ,url: layui.setter.base + 'json/useradmin/role.js' //模拟接口
    ,cols: [[
      {type: 'checkbox', fixed: 'left'}
      ,{field: 'id', width: 80, title: 'ID', sort: true}
      ,{field: 'rolename', title: '角色名'}
      ,{field: 'limits', title: '拥有权限'}
      ,{field: 'descr', title: '具体描述'}
      ,{title: '操作', width: 150, align: 'center', fixed: 'right', toolbar: '#table-useradmin-admin'}
    ]]
    ,text: '对不起，加载出现异常！'
  });
  
  //监听工具条
  table.on('tool(LAY-user-back-role)', function(obj){
    var data = obj.data;
    if(obj.event === 'del'){
      layer.confirm('确定删除此角色？', function(index){
        obj.del();
        layer.close(index);
      });
    }else if(obj.event === 'edit'){
      var tr = $(obj.tr);

      layer.open({
        type: 2
        ,title: '编辑角色'
        ,content: '../../../views/user/administrators/roleform.html'
        ,area: ['500px', '480px']
        ,btn: ['确定', '取消']
        ,yes: function(index, layero){
          var iframeWindow = window['layui-layer-iframe'+ index]
          ,submit = layero.find('iframe').contents().find("#LAY-user-role-submit");

          //监听提交
          iframeWindow.layui.form.on('submit(LAY-user-role-submit)', function(data){
            var field = data.field; //获取提交的字段
            
            //提交 Ajax 成功后，静态更新表格中的数据
            //$.ajax({});
            table.reload('LAY-user-back-role'); //数据刷新
            layer.close(index); //关闭弹层
          });  
          
          submit.trigger('click');
        }
        ,success: function(layero, index){
        
        }
      })
    }
  });

  exports('useradmin', {})
});