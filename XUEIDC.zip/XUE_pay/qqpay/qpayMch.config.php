<?php

/**
 * qpayMch.config.php
 * Created by HelloWorld
 * vers: v1.0.0
 * User: Tencent.com
 */
class QpayMchConf
{
    /**
     * QQ钱包商户号
     */
	 
    const MCH_ID = QQ_API_APPID;//'1504303431';

    /**
     * API密钥。
     * QQ钱包商户平台(http://qpay.qq.com/)获取
     */
	 //exit($api_key);
    const MCH_KEY = QQ_API_KEY;//'41d0a65a7a5e5058400a78f1b7081955';

}