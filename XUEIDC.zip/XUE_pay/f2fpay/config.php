<?php
$config = array (
	//签名方式,默认为RSA2(RSA2048)
	'sign_type' => "RSA2",

	//支付宝公钥
	'alipay_public_key' => $alipay_g,

	//商户私钥
	'merchant_private_key' => $alipay_s,

	//编码格式
	'charset' => "UTF-8",

	//支付宝网关
	'gatewayUrl' => "https://openapi.alipay.com/gateway.do",

	//应用ID
	'app_id' => $alipay_appid,

	//异步通知地址,只有扫码支付预下单可用
	'notify_url' => $ali2_notify,

	//登录返回页面
	'redirect_uri' => ($_SERVER['SERVER_PORT'] == '443' ? 'https://' : 'http://').$_SERVER['HTTP_HOST'].'/?m=user',
);