﻿<?php
$sysfoorder =  $_GET['out_trade_no'];
$url = "index.php?m=user&c=index&orders=".$sysfoorder;
header ("location:$url");	
?>