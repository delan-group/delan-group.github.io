<?php
$lifeTime = 1800; 
date_default_timezone_set('prc');
$Modular_hou = "XUE";
session_start();
ini_set('max_execution_time', '0');
if($_SESSION['datetts']==""){$_SESSION['datetts']= time()+$lifeTime;}else{
if($_SESSION['datetts']<time()){
session_unset();
session_destroy();	
}else{$_SESSION['datetts']= time()+$lifeTime;}}
?>