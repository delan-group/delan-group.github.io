<?php
//配置文件
return [
    'zh-cn'=>'中文',
    'zh-hk'=>'繁体',
    'en-us'=>'English',
];
