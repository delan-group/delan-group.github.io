$L = {
    1001:'The network timed out, please try again',
    1002:'Please select the data to be operated',
    1003:'Are you sure you want to batch delete?',
    1004:'Please select the deleted data',
    1005:'Are you sure to delete?',
    1006:'Data parsing failed. Please try again',
    1007:'Error message:',
    1008:'Turn off after 5 seconds',
    1009:'2 seconds after the closure',
    1010:'confirm',
    1011:'Prompt message',
    1012:'cancel',
    1013:'Data list'
};